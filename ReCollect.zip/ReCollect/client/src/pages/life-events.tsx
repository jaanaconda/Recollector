import { LifeEvents } from "@/components/life-events";
import { LifeEventMessages } from "@/components/life-event-messages";

export default function LifeEventsPage() {
  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <LifeEvents userId="user-1" />
        <LifeEventMessages userId="user-1" />
      </div>
    </div>
  );
}