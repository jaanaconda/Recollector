import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Plus, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { NotificationBell } from "@/components/notification-bell";
import { SettingsModal } from "@/components/settings-modal";

interface SidebarProps {
  onAddMemories: () => void;
}

export function Sidebar({ onAddMemories }: SidebarProps) {
  const userId = "user-1"; // Default user for demo
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const { data: categories = [] } = useQuery({
    queryKey: ["/api/memory-categories"],
  });

  const { data: stats } = useQuery({
    queryKey: ["/api/stats", userId],
  });

  const getProgressColor = (progress: number) => {
    if (progress >= 70) return "bg-secondary";
    if (progress >= 50) return "bg-accent";
    if (progress >= 30) return "bg-primary";
    return "bg-red-400";
  };

  return (
    <div className="lg:col-span-1" data-testid="sidebar">
      <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-warm-gray">Memory Progress</h3>
          <div className="flex items-center space-x-2">
            <NotificationBell />
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsSettingsOpen(true)}
              className="p-2"
              data-testid="button-settings"
            >
              <Settings size={18} />
            </Button>
          </div>
        </div>
        
        <div className="space-y-4">
          {categories.map((category: any) => (
            <div key={category.id} className="flex items-center justify-between">
              <span className="text-sm text-soft-gray" data-testid={`text-category-${category.name.toLowerCase()}`}>
                {category.name}
              </span>
              <div className="flex items-center space-x-2">
                <div className="w-16 h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full ${getProgressColor(category.progress)}`}
                    style={{ width: `${category.progress}%` }}
                  ></div>
                </div>
                <span className="text-xs text-soft-gray" data-testid={`text-progress-${category.name.toLowerCase()}`}>
                  {category.progress}%
                </span>
              </div>
            </div>
          ))}
        </div>
        
        <Button 
          onClick={onAddMemories}
          className="w-full mt-6 bg-primary text-white hover:bg-primary/90"
          data-testid="button-add-memories"
        >
          <Plus size={16} className="mr-2" />
          Add Memories
        </Button>
      </div>
      
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h3 className="text-lg font-semibold text-warm-gray mb-4">Your Story</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-soft-gray">Total Memories</span>
            <span className="font-semibold text-warm-gray" data-testid="text-memory-count">
              {stats?.memoryCount || 0}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-soft-gray">Conversations</span>
            <span className="font-semibold text-warm-gray" data-testid="text-conversation-count">
              {stats?.conversationCount || 0}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-soft-gray">Family Members</span>
            <span className="font-semibold text-warm-gray" data-testid="text-family-count">
              {stats?.familyCount || 0}
            </span>
          </div>
        </div>
      </div>

      <SettingsModal 
        isOpen={isSettingsOpen} 
        onClose={() => setIsSettingsOpen(false)} 
      />
    </div>
  );
}
